/*
 ============================================================================
 Name        : ConwayGame.c
 Author      : Ruchi Sharma
 Version     :  1.1   Gets data from a file mentioned by the user and then starts the game
	      : 1.2   Gets the data from the file by the user and starts the game and also prints the next generation as well
	      : 1.3  Take the input by the user and then starts the game and also print the next generation as well
 Copyright   : Ruchi Sharma
 Description : Conway Game of Life
 ============================================================================
 */


#include <graphics.h>
#include <stdio.h>
#include<dos.h>
#define ESC 27
#include<conio.h>
union REGS in, out;
int x,y,cl,a,b;
typedef enum{false,true} bool;

/***********
 * This function is used to show the mouse pointer
 */
int callmouse()
{ in.x.ax=1;
int86(51,&in,&out);
return 1;
}
/***********
 * This function is used to retrict the mouse postion in a box
 *@parameter x1    set the minimum value cordinate of x1
 *@parameter y1    set the minimum value cordinate of y1
 *@parameter x2    set the maximum value cordinate of x2
 *@parameter y2    set the maximum value cordinate of y2
 */
void restrictmouseptr(int x1, int y1, int x2,int y2)
{
in.x.ax=7;
in.x.cx=x1;
in.x.dx=x2;
int86(51,&in,&out);
in.x.ax=8;
in.x.cx=y1;
in.x.dx=y2;
int86(51,&in,&out);
}
/***********
 * This function is used to get mouse postion
 *@parameter *xpos     this is x co-ordinate of the postion
 *@parameter *ypos     this is y co-ordinate of the postion
 *@parameter *click    this is used click on the postion of mouse
 */
void mouseposi(int *xpos, int *ypos,int *click)
{ 	in.x.ax=3;
	int86(51,&in,&out);
	*click=out.x.bx;
	*xpos=out.x.cx;
	*ypos=out.x.dx;
}
/***********
 * This function is used to hide the mouse pointer
 */
int mousehide()
{	 in.x.ax=2;
	int86(51,&in,&out);
	return 1;
}
/***********
 * This function is used to show the mouse pointer
 */
void setposi(int *xpos,int *ypos)
{ 	in.x.ax=4;
	in.x.cx=*xpos;
	in.x.dx=*ypos;
	int86(51,&in,&out);
}

void grid()
{
	int i,j;

	for(i=100; i<200; i=i+10)
		{ for(j=100; j<200; j=j+10)
			{  rectangle (i, j, i+10,j+10);

			}
		}
}

/***********
 * This function initializes the entire board with the value 0 or false
 *@parameter *arr  this is array in which the board is stored and which is to be initialized
 *@parameter m     this is the number of row of the board
 *@parameter n     this is the number of column of the board
 */
void assign(bool* arr, int m, int n)
{ 	int i, j;
	for(i=0;i<=m;i++){
		for ( j=0; j<=n; j++)
			*((arr+(i*n))+j) = 0;
	}
}

/*************
 * This function copy the entire board to another array
 *@parameter *arr  this is array in which the board will be copied to
 *@parameter *arr1  this is array from which the board will be copied from
 *@parameter m     this is the number of row of the board
 *@parameter n     this is the number of column of the board
 */
void copyboard(bool* arr, bool* arr1, int m, int n)
{   int i, j;
	for( i=0;i<=m;i++){
		for ( j=0; j<=n; j++)
			*((arr+(i*n))+j)=*((arr1+(i*n))+j);
	}
}

/***********
 * This function is to remove the highlights on dead cell
 *@parameter x    this is x co-ordinate to get the position of cell
 *@parameter y    this is y co-ordinate to get the position of cell
 */
void removehighlights( int x, int y)
{
	int i,j,k,l;
	k=((x+10)*10)+10;
	l=((y+10)*10)+10;
	for( i=((x+10)*10); i<k;i++){
		for( j=((y+10)*10); j<l;j++){
		putpixel(i,j,0);
		}
	}
}
/***********
 * This function is used to highlights on dead cell
 *@parameter x    this is x co-ordinate to get the position of cell
 *@parameter y    this is y co-ordinate to get the position of cell
 */
void highlights( int x, int y)
{
	int i,j,k,l;
	k=((x+10)*10)+10;
	l=((y+10)*10)+10;
	for( i=((x+10)*10)+1; i<k-1;i++){
		for( j=((y+10)*10)+1; j<l-1;j++){
		putpixel(i,j,10);
		}
	}
}
/*********
 *This function gets the initial state of the board from the user and marks it on the board
 *@parameter *arr  this is the board on which the point is being marked
 *@parameter m     this is the number of row where the function will put a mark
 *@parameter n     this is the number of column where the function will put a mark
 *@parameter c     this is the total number of column of the board
*/
void assignPoint(bool* arr, int m, int n, int c)
	{
	if(*(arr+(m*c)+n)==1)
	 {
		*(arr+(m*c)+n)=0;;
		removehighlights(m,n);
	}
	else if(*(arr+(m*c)+n)==0)
	{ 	*(arr+(m*c)+n)= 1;
		highlights(m,n);
	}
}
/********
 * This function governs the main game by validating the four rules of the conway game of life
 * 1. Any live cell with fewer than two live neighbours dies, as if by underpopulation   (UnderPopulation rule )
 * 2. Any live cell with more than three live neighbours dies, as if by overpopulation.  (Overpopulation rule)
 * 3. Any live cell with two or three live neighbours lives on to the next generation.    (Sustainibility rule)
 * 4. Any dead cell with exactly three live neighbours becomes a live cell, as if by reproduction. (Reproduction rule)
 * it hovers over the each cell of the entire board separetely while checking its number of neighbours and
 * implementing the four rules and making changes in a copy board.
 *
 * Notice: the 3rd rule is not being implemented because the live cell does not need to be changed according to the rule and will be allowed to go to next generation
 *@parameter *arr  this is array in which the board is stored and which is to be checked for number of neighbours
 *@parameter *arr1  this is array in which the copy board is stored and where the changes are made according to the rules after checking the number of neighbours
 *@parameter m     this is the number of row of the board
 *@parameter n     this is the number of column of the board
 */
void play(bool* arr, bool* arr1, int m, int n)
{   int i, j, a1, b1,c1, d1, e1,f1,g1,h1,a2,b2,c2,d2,e2, f2, g2, h2;
	for( i=0;i<m;i++){
				for (j=0; j<n; j++){

	// these two are the variables which is used as a counter to count the number of neighbours
	int f = 0, c = 0;

				if(*((arr+(i*n))+j) == 1)  // if a live cell is found
				{

					//checking if its top row element
					if(i == 0 )
					{
					 g1= i+1, g2 = j; // down
					if(*((arr+(g1*n))+g2) == 1)
						{f++;}

					if(j == 0)// checking if it is left most element
						{
						 e1 = i, e2 = j+1; // right side
						if (*((arr+(e1*n))+e2) == 1)
							f++;
						 h1 = i+1, h2 = j+1; // down right
						if (*((arr+(h1*n))+h2) == 1)
							f++;
						}
						else if(j == n) // checking if it is right most element
						{
							 d1 = i, d2 = j-1; // left side
							if (*((arr+(d1*n))+d2) == 1)
								f++;
							 f1 = i+1, f2 = j-1;// down left
							if (*((arr+(f1*n))+f2) == 1)
								f++;
						}
						else
						{
							 e1 = i, e2 = j+1; // right side
							if (*((arr+(e1*n))+e2) == 1)
								f++;
							 h1 = i+1, h2 = j+1; // down right
							if (*((arr+(h1*n))+h2) == 1)
								f++;
							 d1 = i, d2 = j-1; // left side
							if (*((arr+(d1*n))+d2) == 1)
								f++;
							 f1 = i+1, f2 = j-1;// down left
							if (*((arr+(f1*n))+f2) == 1)
								f++;

						}
					}
					//checking if its last row element
					else if(i == m)
					{
					 b1 = i-1, b2 = j; // up
						if (*((arr+(b1*n))+b2) == 1)
							f++;

						if(j == 0)
						{
						c1 = i-1, c2 = j+1; // up right
						if (*((arr+(c1*n))+c2) == 1)
							f++;
						e1 = i, e2 = j+1; // right side
						if (*((arr+(e1*n))+e2) == 1)
							f++;
						}
						else if(j == n)
						{
							a1 = i-1, a2 = j-1; //up left
							if (*((arr+(a1*n))+a2) == 1)
									f++;
							d1 = i, d2 = j-1; // left side
							if (*((arr+(d1*n))+d2) == 1)
									f++;
						}
						else
						{
							 c1 = i-1, c2 = j+1; // up right
							if (*((arr+(c1*n))+c2) == 1)
								f++;
							 e1 = i, e2 = j+1; // right side
							if (*((arr+(e1*n))+e2) == 1)
								f++;
							 a1 = i-1, a2 = j-1; //up left
							if (*((arr+(a1*n))+a2) == 1)
								f++;
						  d1 = i, d2 = j-1; // left side
							if (*((arr+(d1*n))+d2) == 1)
								f++;
						}
					}
					//checking if its not the first or last row  element
					else if (i != 0 && i != m)
					{
					 b1 = i-1, b2 = j; // up
						if (*((arr+(b1*n))+b2) == 1)
								f++;
						 g1= i+1, g2 = j; // down
						if (*((arr+(g1*n))+g2) == 1)
								f++;

						if(j == 0)// checking if it is first column element
						{
							 c1 = i-1, c2 = j+1; // up right
							if (*((arr+(c1*n))+c2) == 1)
								f++;
							 e1 = i, e2 = j+1; // right side
							if (*((arr+(e1*n))+e2) == 1)
								f++;
							 h1 = i+1, h2 = j+1; // down right
							if (*((arr+(h1*n))+h2) == 1)
								f++;
						}
						else if(j == n)
						{
							 a1 = i-1, a2 = j-1; //up left
							if (*((arr+(a1*n))+a2) == 1)
									f++;
							 d1 = i, d2 = j-1; // left side
							if (*((arr+(d1*n))+d2) == 1)
									f++;
							 f1 = i+1, f2 = j-1;// down left
							if (*((arr+(f1*n))+f2) == 1)
									f++;
						}
						else
						{
							 c1 = i-1, c2 = j+1; // up right
							if (*((arr+(c1*n))+c2) == 1)
								f++;
							 e1 = i, e2 = j+1; // right side
							if (*((arr+(e1*n))+e2) == 1)
								f++;
							 h1 = i+1, h2 = j+1; // down right
							if (*((arr+(h1*n))+h2) == 1)
								f++;
							 a1 = i-1, a2 = j-1; //up left
							if (*((arr+(a1*n))+a2) == 1)
								f++;
							 d1 = i, d2 = j-1; // left side
							if (*((arr+(d1*n))+d2) == 1)
								f++;
							 f1 = i+1, f2 = j-1;// down left
							if (*((arr+(f1*n))+f2) == 1)
								f++;
						}
					}
					else{
					 a1 = i-1, a2 = j-1; //up left
					if (*((arr+(a1*n))+a2) == 1)
						f++;
					 b1 = i-1, b2 = j; // up
					if (*((arr+(b1*n))+b2) == 1)
						f++;
					 c1 = i-1, c2 = j+1; // up right
					if (*((arr+(c1*n))+c2) == 1)
						f++;
					 d1 = i, d2 = j-1; // left side
					if (*((arr+(d1*n))+d2) == 1)
						f++;
					 e1 = i, e2 = j+1; // right side
					if (*((arr+(e1*n))+e2) == 1)
						f++;
					 f1 = i+1, f2 = j-1;// down left
					if (*((arr+(f1*n))+f2) == 1)
							f++;
					 g1= i+1, g2 = j; // down
					if (*((arr+(g1*n))+g2) == 1)
							f++;
					 h1 = i+1, h2 = j+1; // down right
					if (*((arr+(h1*n))+h2) == 1)
							f++;}

					if(f < 2 )                         // implementing the 1st rule which is the UnderPopulation rule
						*((arr1+(i*n))+j) = 0;        // marking the cell dead by making it 0 or false
					if( f > 3)                         //implementing the 2nd rule which is the Overpopulation rule
						*((arr1+(i*n))+j) = 0;
				}

				if(*((arr+(i*n))+j) == 0) // if a dead cell is found
								{
					//checking if its top row element
										if(i == 0 )
										{
										int g1= i+1, g2 = j; // down
										if(*((arr+(g1*n))+g2) == 1)
											{c++;}

										if(j == 0)// checking if it is left most element
											{
											e1 = i, e2 = j+1; // right side
											if (*((arr+(e1*n))+e2) == 1)
											     {	c++;}
											 h1 = i+1, h2 = j+1; // down right
											if (*((arr+(h1*n))+h2) == 1)
												c++;
											}
											else if(j == n) // checking if it is right most element
											{
												 d1 = i, d2 = j-1; // left side
												if (*((arr+(d1*n))+d2) == 1)
													c++;
												 f1 = i+1, f2 = j-1;// down left
												if (*((arr+(f1*n))+f2) == 1)
													c++;
											}
											else
											{
												 e1 = i, e2 = j+1; // right side
												if (*((arr+(e1*n))+e2) == 1)
													{c++;}
												 h1 = i+1, h2 = j+1; // down right
												if (*((arr+(h1*n))+h2) == 1)
													c++;
												 d1 = i, d2 = j-1; // left side
												if (*((arr+(d1*n))+d2) == 1)
													c++;
												f1 = i+1, f2 = j-1;// down left
												if (*((arr+(f1*n))+f2) == 1)
													c++;

											}
										}
										//checking if its last row element
										else if(i == m)
										{
											 b1 = i-1, b2 = j; // up
											if (*((arr+(b1*n))+b2) == 1)
												c++;

											if(j == 0)
											{
											 c1 = i-1, c2 = j+1; // up right
											if (*((arr+(c1*n))+c2) == 1)
												c++;
											 e1 = i, e2 = j+1; // right side
											if (*((arr+(e1*n))+e2) == 1)
												c++;
											}
											else if(j == n)
											{
												 a1 = i-1, a2 = j-1; //up left
												if (*((arr+(a1*n))+a2) == 1)
														c++;
												 d1 = i, d2 = j-1; // left side
												if (*((arr+(d1*n))+d2) == 1)
														c++;
											}
											else
											{
												 c1 = i-1, c2 = j+1; // up right
												if (*((arr+(c1*n))+c2) == 1)
													c++;
												 e1 = i, e2 = j+1; // right side
												if (*((arr+(e1*n))+e2) == 1)
													c++;
											 a1 = i-1, a2 = j-1; //up left
												if (*((arr+(a1*n))+a2) == 1)
													c++;
												 d1 = i, d2 = j-1; // left side
												if (*((arr+(d1*n))+d2) == 1)
													c++;
											}
										}
										//checking if its not the first or last row  element
										else if (i != 0 && i != m)
										{
											 b1 = i-1, b2 = j; // up
											if (*((arr+(b1*n))+b2) == 1)
													c++;
											 g1= i+1, g2 = j; // down
											if (*((arr+(g1*n))+g2) == 1)
													c++;

											if(j == 0)// checking if it is first column element
											{
												 c1 = i-1, c2 = j+1; // up right
												if (*((arr+(c1*n))+c2) == 1)
													c++;
												 e1 = i, e2 = j+1; // right side
												if (*((arr+(e1*n))+e2) == 1)
													c++;
												 h1 = i+1, h2 = j+1; // down right
												if (*((arr+(h1*n))+h2) == 1)
													c++;
											}
											else if(j == n)
											{
												 a1 = i-1, a2 = j-1; //up left
												if (*((arr+(a1*n))+a2) == 1)
														c++;
												 d1 = i, d2 = j-1; // left side
												if (*((arr+(d1*n))+d2) == 1)
														c++;
												 f1 = i+1, f2 = j-1;// down left
												if (*((arr+(f1*n))+f2) == 1)
														c++;
											}
											else
											{
												 c1 = i-1, c2 = j+1; // up right
												if (*((arr+(c1*n))+c2) == 1)
													c++;
												 e1 = i, e2 = j+1; // right side
												if (*((arr+(e1*n))+e2) == 1)
													c++;
												 h1 = i+1, h2 = j+1; // down right
												if (*((arr+(h1*n))+h2) == 1)
													c++;
												 a1 = i-1, a2 = j-1; //up left
												if (*((arr+(a1*n))+a2) == 1)
													c++;
												 d1 = i, d2 = j-1; // left side
												if (*((arr+(d1*n))+d2) == 1)
													c++;
												 f1 = i+1, f2 = j-1;// down left
												if (*((arr+(f1*n))+f2) == 1)
													c++;
											}
										}
										else{
										 a1 = i-1, a2 = j-1; //up left
										if (*((arr+(a1*n))+a2) == 1)
											c++;
										 b1 = i-1, b2 = j; // up
										if (*((arr+(b1*n))+b2) == 1)
											c++;
										 c1 = i-1, c2 = j+1; // up right
										if (*((arr+(c1*n))+c2) == 1)
											c++;
										 d1 = i, d2 = j-1; // left side
										if (*((arr+(d1*n))+d2) == 1)
											c++;
										 e1 = i, e2 = j+1; // right side
										if (*((arr+(e1*n))+e2) == 1)
											c++;
										 f1 = i+1, f2 = j-1;// down left
										if (*((arr+(f1*n))+f2) == 1)
												c++;
										 g1= i+1, g2 = j; // down
										if (*((arr+(g1*n))+g2) == 1)
												c++;
										 h1 = i+1, h2 = j+1; // down right
										if (*((arr+(h1*n))+h2) == 1)
												c++;}
									if( c==3) // implementing the 3rd rule which is the Reproduction rule
										*((arr1+(i*n))+j) = 1; // making the cell alive by marking it 1 or true
	}
	}
	}


}
/************
 * This function prints the entire board on the console
 *@parameter *arr  this is array in which the board is stored and which is to be printed
 *@parameter m     this is the number of row of the board
 *@parameter n     this is the number of column of the board
*/
void printBoard(bool* arr, int m, int n)
{ int i, j;
	for( i=0;i<m;i++){
		for ( j=0; j<n; j++)
		{
			if(*((arr+(i*n))+j) == 1)                        // if the value is true or 1 then it leaves a mark or a asting *
				highlights(i,j);
			else                     // if the value is false or 0 then it leaves a space or blank
				removehighlights(i,j);
		}
		}
}


int main()
{

int gd=DETECT,gm;
int x,y,cl,a,b,q,s;
int ch=0;



bool *arr=(bool*) malloc(10* 10* sizeof(bool));         // initializing 2d boolean array by allocating its memory dynamically for storing the main board
bool *arr1=(bool*) malloc(10* 10* sizeof(bool));        // initializing 2d boolean array by allocating its memory dynamically for storing the copy of the board

assign(arr,10,10);          // initializing the entire main board
assign(arr1,10,10);        // initializing the entire copy board

clrscr();
initgraph(&gd,&gm, " ");

a=100;
b=400;
setposi(&a,&b);           //set the position of the board
callmouse();
    restrictmouseptr(100,100,200,210);
	printf("Conway Game Of Life\n");
	printf("Click on the grid for enter the intial state\n");
	printf("Press any key to start the game");
grid( );
do{
	gotoxy(50,50);
	grid( );
	mouseposi(&x,&y,&cl);
	if(cl==1){
	 q= ((x/10)%10);
	 s= ((y/10)%10);
	assignPoint(arr, q, s, 10);         // the coordinates are now used to put the point in the main board
	}
	} while(!kbhit());


	mousehide();
	copyboard(arr1, arr,10,10);		//copies the main board in to the copy board
	clrscr();

	while((ch=getch())!=ESC){
	clrscr();
		     // this loop asks and shows the next generation on the console until the user inputs 0
	  gotoxy(50,50);
	printf("\n \n Do you wish to see the next generation Enter or ESC:"); //asks user whether he wants to see the next generation

	   play(arr,arr1, 10, 10);               // plays the game
	   printBoard(arr1, 10, 10);            // printing the board after each round
	  grid( );

	while(kbhit()){
	 getch();}

	   copyboard(arr,arr1, 10, 10);     //copies the main board in to the copy board
	   }
	   clrscr();
	printf("\n\n\tPress any key to exit");
	getch();


return 0;
}

